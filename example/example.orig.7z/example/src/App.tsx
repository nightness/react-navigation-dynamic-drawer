import React from 'react'

import { ExampleComponent } from 'react-navigation-dynamic-drawer'
import 'react-navigation-dynamic-drawer/dist/index.css'

const App = () => {
  return <ExampleComponent text="Create React Library Example 😄" />
}

export default App
